// ----------------------------------------------------------------------
// 1. INTERFACE
// ----------------------------------------------------------------------

/**
 * Interface que define o contrato para um objeto Livro.
 */
interface Livro {
    titulo: string;
    autor: string;
    disponivel: boolean;
}

// ----------------------------------------------------------------------
// 2. CLASSE BIBLIOTECA
// ----------------------------------------------------------------------

/**
 * Classe Biblioteca que gerencia o catálogo de livros.
 */
class Biblioteca {
    // Array tipado para aceitar apenas objetos que sigam o contrato Livro
    private acervo: Livro[] = [];

    constructor() {
        // Inicializa a biblioteca com alguns livros de exemplo
        this.acervo.push(
            { titulo: "O Senhor dos Anéis", autor: "J.R.R. Tolkien", disponivel: true },
            { titulo: "1984", autor: "George Orwell", disponivel: false },
            { titulo: "Cem Anos de Solidão", autor: "Gabriel García Márquez", disponivel: true },
            { titulo: "Orgulho e Preconceito", autor: "Jane Austen", disponivel: false }
        );
        console.log(`Biblioteca inicializada com ${this.acervo.length} livros.`);
    }

    /**
     * Retorna um array contendo apenas os livros que estão disponíveis (disponivel = true).
     *
     * @returns Um array de objetos Livro disponíveis.
     */
    public buscarLivrosDisponiveis(): Livro[] {
        // Usa o método filter() para criar um novo array apenas com os itens
        // que satisfazem a condição 'livro.disponivel === true'.
        return this.acervo.filter(livro => livro.disponivel === true);
    }
}

// --- Exemplo de Uso ---

const minhaBiblioteca = new Biblioteca();

console.log("\n--- Checagem de Disponibilidade ---");

// Chama o método para buscar apenas os livros disponíveis
const livrosDisponiveis = minhaBiblioteca.buscarLivrosDisponiveis();

if (livrosDisponiveis.length > 0) {
    console.log(`Temos ${livrosDisponiveis.length} livros disponíveis:`);
    livrosDisponiveis.forEach(livro => {
        console.log(`[Disponível] - ${livro.titulo} por ${livro.autor}`);
    });
} else {
    console.log("Nenhum livro disponível no momento.");
}