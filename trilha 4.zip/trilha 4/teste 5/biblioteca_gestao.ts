// ----------------------------------------------------------------------
// 1. INTERFACE
// ----------------------------------------------------------------------

/**
 * Interface que define o contrato para um objeto Livro detalhado na gestão da biblioteca.
 */
interface LivroBiblioteca {
    titulo: string;
    autor: string;
    genero: string;
    disponivel: boolean;
}

// ----------------------------------------------------------------------
// 2. CLASSE BIBLIOTECA GESTÃO
// ----------------------------------------------------------------------

/**
 * Classe BibliotecaGestao que gerencia um catálogo de livros
 * com funcionalidades avançadas de busca e ordenação.
 */
class BibliotecaGestao {
    // Array tipado que armazena o acervo
    private acervo: LivroBiblioteca[] = [];

    constructor() {
        // Inicializa o acervo com dados de exemplo
        this.acervo.push(
            { titulo: "O Pássaro e a Árvore", autor: "Ana Clara", genero: "Ficção Científica", disponivel: true },
            { titulo: "A Arte da Guerra", autor: "Sun Tzu", genero: "Estrategia", disponivel: true },
            { titulo: "Memórias Póstumas", autor: "Machado de Assis", genero: "Clássico", disponivel: false },
            { titulo: "Duna", autor: "Frank Herbert", genero: "Ficção Científica", disponivel: true },
            { titulo: "Dom Casmurro", autor: "Machado de Assis", genero: "Clássico", disponivel: true }
        );
        console.log(`\nSistema de Gestão iniciado com ${this.acervo.length} livros.`);
    }

    /**
     * Filtra o acervo e retorna livros que pertencem ao gênero especificado.
     * @param genero O gênero a ser filtrado (string).
     * @returns Array de LivroBiblioteca.
     */
    public filtrarPorGenero(genero: string): LivroBiblioteca[] {
        // Usa filter() e toLowerCase() para uma busca que não diferencia maiúsculas/minúsculas
        const generoBusca = genero.toLowerCase();
        return this.acervo.filter(livro => livro.genero.toLowerCase() === generoBusca);
    }

    /**
     * Retorna todos os livros escritos por um autor específico.
     * @param autor O nome completo do autor (string).
     * @returns Array de LivroBiblioteca.
     */
    public buscarPorAutor(autor: string): LivroBiblioteca[] {
        // Usa filter() para encontrar correspondência exata de autor
        return this.acervo.filter(livro => livro.autor === autor);
    }

    /**
     * Retorna uma lista de todos os livros disponíveis, ordenada alfabeticamente pelo título.
     * @returns Array de LivroBiblioteca ordenado.
     */
    public obterLivrosDisponiveisOrdenados(): LivroBiblioteca[] {
        // 1. Filtra: Mantém apenas os livros com 'disponivel: true'
        const disponiveis = this.acervo.filter(livro => livro.disponivel);

        // 2. Ordena: Usa o método sort() para ordenar pelo título
        // A função de comparação (a, b) compara os títulos em ordem alfabética
        return disponiveis.sort((a, b) => a.titulo.localeCompare(b.titulo));
    }
}

// --- Exemplo de Uso ---

const gestao = new BibliotecaGestao();

// A. Teste de Filtrar por Gênero
const ficcao = gestao.filtrarPorGenero("ficção científica");
console.log("\n--- A. Livros de Ficção Científica ---");
ficcao.forEach(l => console.log(`[${l.genero}] ${l.titulo}`));

// B. Teste de Buscar por Autor
const machado = gestao.buscarPorAutor("Machado de Assis");
console.log("\n--- B. Livros de Machado de Assis ---");
machado.forEach(l => console.log(`[${l.autor}] ${l.titulo}`));

// C. Teste de Ordenação e Disponibilidade
const ordenados = gestao.obterLivrosDisponiveisOrdenados();
console.log("\n--- C. Disponíveis Ordenados por Título ---");
ordenados.forEach(l => console.log(`[Disponível] ${l.titulo} (${l.autor})`));