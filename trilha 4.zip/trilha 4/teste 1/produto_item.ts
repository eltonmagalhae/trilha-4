// ----------------------------------------------------------------------
// 1. INTERFACE
// ----------------------------------------------------------------------

/**
 * Interface que define o contrato (estrutura) de um Produto.
 * Qualquer classe que implementar esta interface deve possuir
 * estas três propriedades com seus respectivos tipos.
 */
interface Produto {
    id: number;
    nome: string;
    preco: number;
}

// ----------------------------------------------------------------------
// 2. CLASSE QUE IMPLEMENTA A INTERFACE
// ----------------------------------------------------------------------

/**
 * Classe ItemLoja que implementa a interface Produto,
 * garantindo que todas as propriedades da interface sejam definidas.
 */
class ItemLoja implements Produto {
    // As propriedades da interface Produto devem ser declaradas aqui
    public id: number;
    public nome: string;
    public preco: number;

    /**
     * Construtor da classe ItemLoja.
     * Atribui valores iniciais a todas as propriedades da interface.
     * @param id O identificador único do produto.
     * @param nome O nome do produto.
     * @param preco O preço unitário do produto.
     */
    constructor(id: number, nome: string, preco: number) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        console.log(`Novo item criado: ID ${this.id} - ${this.nome}, R$ ${this.preco.toFixed(2)}.`);
    }

    /**
     * Método opcional para demonstrar o uso das propriedades.
     */
    public exibirInfo(): void {
        console.log(`Produto: ${this.nome} | ID: ${this.id} | Preço: R$ ${this.preco.toFixed(2)}`);
    }
}

// --- Exemplo de Uso ---

const caneca = new ItemLoja(101, "Caneca Personalizada", 29.90);
const caderno = new ItemLoja(102, "Caderno A4", 19.50);

console.log("\nDetalhes dos itens:");
caneca.exibirInfo();
caderno.exibirInfo();

// Você pode tratar caneca como um tipo Produto:
const itemGenerico: Produto = caneca;
console.log(`Preço do item genérico: R$ ${itemGenerico.preco.toFixed(2)}`);