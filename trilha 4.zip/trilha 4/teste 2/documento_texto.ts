// ----------------------------------------------------------------------
// 1. INTERFACE
// ----------------------------------------------------------------------

/**
 * Interface que define o contrato de um Documento.
 */
interface Documento {
    titulo: string;
    conteudo: string;
}

// ----------------------------------------------------------------------
// 2. CLASSE QUE IMPLEMENTA A INTERFACE
// ----------------------------------------------------------------------

/**
 * Classe Texto que implementa o contrato Documento.
 */
class Texto implements Documento {
    // Propriedades obrigatórias da interface
    public titulo: string;
    public conteudo: string;

    /**
     * Construtor da classe Texto.
     */
    constructor(titulo: string, conteudo: string) {
        this.titulo = titulo;
        this.conteudo = conteudo;
        console.log(`Documento '${this.titulo}' criado.`);
    }

    /**
     * Retorna uma string com o título e o conteúdo formatados.
     * @returns String formatada: "Título: [titulo], Conteúdo: [conteudo]"
     */
    public exibir(): string {
        return `Título: ${this.titulo}, Conteúdo: ${this.conteudo}`;
    }
}

// --- Exemplo de Uso ---

const relatorio = new Texto(
    "Relatório Anual",
    "Os resultados do ano fiscal superaram as expectativas."
);

const artigo = new Texto(
    "TypeScript & Interfaces",
    "Interfaces definem a estrutura de dados de uma forma clara."
);

console.log("\n--- Exibição Formatada ---");
console.log(`Relatório: ${relatorio.exibir()}`);
console.log(`Artigo: ${artigo.exibir()}`);