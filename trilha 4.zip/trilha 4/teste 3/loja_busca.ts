// ----------------------------------------------------------------------
// 1. INTERFACE
// ----------------------------------------------------------------------

/**
 * Interface que define o contrato de um item de produto dentro da loja.
 */
interface ProdutoLoja {
    codigo: number;
    nome: string;
}

// ----------------------------------------------------------------------
// 2. CLASSE QUE CONTÉM O ARRAY E O MÉTODO DE BUSCA
// ----------------------------------------------------------------------

/**
 * Classe Loja que gerencia um catálogo de produtos.
 */
class Loja {
    // Array tipado para aceitar apenas objetos que sigam o contrato ProdutoLoja
    private produtos: ProdutoLoja[] = [];

    constructor() {
        // Inicializa a loja com alguns produtos de exemplo
        this.produtos.push(
            { codigo: 10, nome: "Notebook Gamer" },
            { codigo: 25, nome: "Mouse Óptico" },
            { codigo: 42, nome: "Monitor Ultrawide" }
        );
        console.log(`Loja inicializada com ${this.produtos.length} produtos.`);
    }

    /**
     * Busca um produto dentro do catálogo pelo seu código.
     * Retorna o ProdutoLoja correspondente ou 'undefined' se não for encontrado.
     *
     * @param codigo O código numérico do produto a ser buscado.
     * @returns ProdutoLoja se encontrado, ou undefined.
     */
    public buscarProdutoPorCodigo(codigo: number): ProdutoLoja | undefined {
        // Usa o método find() do array, que retorna o primeiro elemento que satisfaz
        // a condição ou undefined.
        return this.produtos.find(produto => produto.codigo === codigo);
    }
}

// --- Exemplo de Uso ---

const minhaLoja = new Loja();

console.log("\n--- Testando a Busca ---");

// Teste 1: Produto que existe (código 25)
const produtoExistente = minhaLoja.buscarProdutoPorCodigo(25);
if (produtoExistente) {
    console.log(`[SUCESSO] Produto encontrado: Código ${produtoExistente.codigo} - ${produtoExistente.nome}`);
}

// Teste 2: Produto que NÃO existe (código 99)
const produtoInexistente = minhaLoja.buscarProdutoPorCodigo(99);
if (produtoInexistente) {
    // Este bloco não será executado
} else {
    console.log(`[FALHA] Produto com código 99 não encontrado (Retornou: ${produtoInexistente}).`);
}